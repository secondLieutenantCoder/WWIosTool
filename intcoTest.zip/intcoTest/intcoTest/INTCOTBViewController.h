//
//  INTCOTBViewController.h
//  intcoTest
//
//  Created by INTCO 王伟 on 2016/10/12.
//  Copyright © 2016年 INTCO 王伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface INTCOTBViewController : UITabBarController

@end
