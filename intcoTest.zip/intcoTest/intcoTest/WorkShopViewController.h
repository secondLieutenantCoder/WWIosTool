//
//  WorkShopViewController.h
//  代码splite
//
//  Created by INTCO 王伟 on 2016/10/14.
//  Copyright © 2016年 INTCO 王伟. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface WorkShopViewController : UIViewController

-(void) DidTransitionScreenToLandScape:(BOOL)isLabdScape;
@end
