//
//  Consts.h
//  intcoTest
//
//  Created by INTCO 王伟 on 2016/10/21.
//  Copyright © 2016年 INTCO 王伟. All rights reserved.
//


#import <UIKit/UIKit.h>
/**
 *   定义常量
*/
extern const CGFloat kLandScapeWidth;
extern const CGFloat kLandScapeHeight;
extern const CGFloat kPortraitWidth;
extern const CGFloat kPortraitHeight;
extern const CGFloat kTabBarHeight;

