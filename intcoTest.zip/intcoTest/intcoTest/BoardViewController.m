//
//  BoardViewController.m
//  代码splite
// 
//  Created by INTCO 王伟 on 2016/10/17.
//  Copyright © 2016年 INTCO 王伟. All rights reserved.
//

#import "BoardViewController.h"
#import "BoardTableViewCell.h"
#import "BoardDeatailVController.h"//看板详情控制器
#import "BoardModal.h"

@interface BoardViewController ()
/** 账号输入框 */
@property (nonatomic,strong) UITextField * tf;
/** 密码输入框 */
@property (nonatomic,strong) UITextField * pswTF;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tableViewTop;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *searchHeight;
@property (weak, nonatomic) IBOutlet UIView *searchView;
@property (weak, nonatomic) IBOutlet UIButton *searchButton;
@property (nonatomic,strong) BoardDeatailVController  * bdVC;
//测试数据
@property (nonatomic,strong) NSMutableArray * modalArr;
@property (nonatomic,strong) NSMutableArray * pickedModalArr;
//搜索框
@property (weak, nonatomic) IBOutlet UITextField *orderTF;
@property (weak, nonatomic) IBOutlet UITextField *lineTF;


@end

static     NSString * identifier = @"xibCell'";
@implementation BoardViewController
/** lazy */
- (BoardDeatailVController *)bdVC{
    if (_bdVC ==nil) {
        _bdVC = [[BoardDeatailVController alloc] init] ;
    }
    return _bdVC;
}
-(NSMutableArray *)modalArr{
    if (_modalArr == nil) {
        _modalArr =[[NSMutableArray alloc] init];
    }
    return _modalArr;
}
-(NSMutableArray *)pickedModalArr{
    if (_pickedModalArr == nil) {
        _pickedModalArr = [[NSMutableArray alloc] init];
    }
    return _pickedModalArr;
}

#pragma mark - viewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadData];
    
    [self setSubViews];
}
#pragma mark - 加载数据
- (void) loadData{

    for (int i =0; i<100; i++) {//100条模拟数据
        NSString * order     = [NSString stringWithFormat:@"CP-123%02d",i];
        NSString * line      = [NSString stringWithFormat:@"1%02d",i];
        BoardModal * bModal  = [[BoardModal alloc] initWithOrderNum:order andLineNum:line];
        [self.modalArr addObject:bModal];
        
    }
    self.pickedModalArr = _pickedModalArr;
}
#pragma mark - 设置子视图
- (void) setSubViews{
    
//    self.tableView.delegate = self;
//    self.tableView.dataSource = self;
    
    self.tableView.rowHeight = 200;
    // > 1 注册自定义的cell（nib）
    [self.tableView registerNib:[UINib nibWithNibName:@"BoardTableViewCell" bundle:nil] forCellReuseIdentifier:identifier];
    // > 2 定义手势
    UISwipeGestureRecognizer * swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(SwipeGestureAction:)];
    swipe.direction = UISwipeGestureRecognizerDirectionUp;
    [self.searchView addGestureRecognizer:swipe];
    
    // > 3 给搜索框添加观察事件
    [self.orderTF addTarget:self action:@selector(pickOrderAction) forControlEvents:UIControlEventEditingChanged];
    [self.lineTF addTarget:self action:@selector(pickLineAction) forControlEvents:UIControlEventEditingChanged];
}
#pragma mark - 搜索框的编辑响应事件
#pragma mark ** order
- (void) pickOrderAction{

}
#pragma mark ** line
- (void) pickLineAction{

}
#pragma mark - 轻扫手势的响应事件
- (void) SwipeGestureAction:(UIGestureRecognizer *) swipe{

    self.searchButton.selected= NO;
    self.searchHeight.constant = 1;
    [UIView animateWithDuration:0.3 animations:^{
        [self.view layoutSubviews];
    }];
    
}
#pragma mark - tableview的代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.modalArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    

    BoardTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    cell.modal                = self.modalArr[indexPath.row];

    return cell;
}
#pragma mark - 返回cell的高度
//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    
//    return 200;
//}
#pragma mark - 点击搜索按钮
- (IBAction)searchAction:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    if (sender.selected) {
        self.searchHeight.constant = 250;
    }else{
        self.searchHeight.constant =1;
    }
    
    [UIView animateWithDuration:0.3 animations:^{
         [self.view layoutSubviews];
    }];
   
}
#pragma mark - 选中cell，点击cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    self.bdVC.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:self.bdVC animated:YES completion:nil];
}

#pragma mark - 账号密码输入框
- (void) accountAndPsw{

    
     UITextField * tf = [[UITextField alloc] initWithFrame:CGRectMake(200, 200, 300, 60)];
     self.tf = tf;
     tf.backgroundColor = [UIColor grayColor];
     [self.view addSubview:tf];
     
     UITextField * pswTF = [[UITextField alloc] initWithFrame:CGRectMake(200, CGRectGetMaxY(tf.frame)+50, 300, 60)];
     self.pswTF = pswTF;
     pswTF.secureTextEntry = YES;
     pswTF.clearButtonMode = UITextFieldViewModeAlways;
     pswTF.backgroundColor = [UIColor purpleColor];
     [self.view addSubview:pswTF];
     
     UIButton * loginButton = [[UIButton alloc] initWithFrame:CGRectMake(230, CGRectGetMaxY(pswTF.frame)+50, 240, 60)];
     loginButton.titleLabel.font = [UIFont boldSystemFontOfSize:25];
     loginButton.backgroundColor = [UIColor greenColor];
     [loginButton setTitle:@"登录" forState:UIControlStateNormal];
     [loginButton addTarget:self action:@selector(loginAction:) forControlEvents:UIControlEventTouchUpInside];
     [self.view addSubview:loginButton];
    
}
#pragma mark - 登录按钮点击事件
- (void) loginAction:(UIButton * )loginButton{

    // 取得账号密码
    NSString * accountString = self.tf.text;
    NSString * pswString = self.pswTF.text;
    if ([accountString isEqualToString:@"123456"] && [pswString isEqualToString:@"qwerdf"]) {
        
        self.view.backgroundColor = [UIColor cyanColor];
    }else {//账号密码有误
    
        CAKeyframeAnimation * kfAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
        kfAnimation.values = @[@-10,@0,@10,@0];
        kfAnimation.repeatCount = 2;
        kfAnimation.duration = 0.2;
        [loginButton.layer addAnimation:kfAnimation forKey:nil];
    }
 
}

@end
