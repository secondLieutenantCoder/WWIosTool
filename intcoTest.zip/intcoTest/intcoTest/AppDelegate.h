//
//  AppDelegate.h
//  intcoTest
//
//  Created by INTCO 王伟 on 2016/10/7.
//  Copyright © 2016年 INTCO 王伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

