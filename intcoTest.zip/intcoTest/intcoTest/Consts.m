//
//  Consts.m
//  intcoTest
//
//  Created by INTCO 王伟 on 2016/10/21.
//  Copyright © 2016年 INTCO 王伟. All rights reserved.
//

#import "Consts.h"

 const CGFloat kLandScapeWidth   = 768;
 const CGFloat kLandScapeHeight  = 1024;
 const CGFloat kPortraitWidth    = 1024;
 const CGFloat kPortraitHeight   = 768;
 const CGFloat kTabBarHeight     = 49;

