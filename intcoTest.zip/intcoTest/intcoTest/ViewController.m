//
//  ViewController.m
//  intcoTest
//
//  Created by INTCO 王伟 on 2016/10/7.
//  Copyright © 2016年 INTCO 王伟. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController{

    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
   
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    
}



@end
